export function buildGPX(coords, stops = []) {
  return `<?xml version="1.0"?>
<gpx version="1.1">
<trk><trkseg>
${coords.map(c => `<trkpt lat="${c[1]}" lon="${c[0]}"/>`).join("
")}
</trkseg></trk>
</gpx>`;
}
