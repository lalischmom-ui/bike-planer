const API_KEY = import.meta.env.VITE_ORS_KEY;

export async function getRoute(coordinates, bikeType) {
  const profileMap = {
    road: "cycling-road",
    gravel: "cycling-regular",
    mtb: "cycling-mountain"
  };

  const res = await fetch(
    `https://api.openrouteservice.org/v2/directions/${profileMap[bikeType]}/geojson`,
    {
      method: "POST",
      headers: {
        Authorization: API_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ coordinates, preference: "recommended" })
    }
  );

  return res.json();
}
