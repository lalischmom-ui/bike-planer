export function generateRoundPoints(start, distanceKm) {
  const earth = 6371;
  const points = [];

  for (let i = 0; i < 3; i++) {
    const angle = Math.random() * Math.PI * 2;

    const dLat = (distanceKm / 3 / earth) * (180 / Math.PI);
    const dLon = dLat;

    points.push({
      lat: start.lat + dLat * Math.sin(angle),
      lon: start.lon + dLon * Math.cos(angle)
    });
  }

  return points;
}
