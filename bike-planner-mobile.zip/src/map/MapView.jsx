import { useEffect } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export default function MapView({ route }) {
  useEffect(() => {
    if (!route) return;

    const map = L.map("map").setView([51, 13], 8);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "OSM"
    }).addTo(map);

    const coords = route.features?.[0]?.geometry?.coordinates || [];

    const line = coords.map(c => [c[1], c[0]]);

    L.polyline(line, { color: "blue" }).addTo(map);

  }, [route]);

  return <div id="map" style={{ height: "70vh", width: "100%" }} />;
}
