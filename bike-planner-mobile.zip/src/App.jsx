import { useState } from "react";
import MapView from "./map/MapView.jsx";
import { generateRoundPoints } from "./utils/roundtrip.js";
import { getRoute } from "./api/route.js";

export default function App() {
  const [route, setRoute] = useState(null);
  const [bikeType, setBikeType] = useState("road");
  const [distance, setDistance] = useState(60);

  async function createRoute() {
    const start = { lat: 51.05, lon: 13.74 };

    const points = generateRoundPoints(start, distance);

    const coords = [
      [start.lon, start.lat],
      ...points.map(p => [p.lon, p.lat]),
      [start.lon, start.lat]
    ];

    const data = await getRoute(coords, bikeType);
    setRoute(data);
  }

  return (
    <div className="container">
      <h2>🚴 Bike Planner</h2>

      <select onChange={(e) => setBikeType(e.target.value)}>
        <option value="road">Rennrad</option>
        <option value="gravel">Gravel</option>
        <option value="mtb">MTB</option>
      </select>

      <input
        type="number"
        value={distance}
        onChange={(e) => setDistance(e.target.value)}
      />

      <button onClick={createRoute}>Route berechnen</button>

      <MapView route={route} />
    </div>
  );
}
